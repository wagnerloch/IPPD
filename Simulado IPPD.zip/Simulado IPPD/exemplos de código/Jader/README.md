# IPPD
Disciplina de Introdução ao Processamento Paralelo e Distribuído
