mpicc my_mpi_application.c -o my_mpi_application

mpirun -np <numprocs> my_mpi_application 
