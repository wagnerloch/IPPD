#ifndef _SUM_H_
#define _SUM_H_

void selection_sort(int *v, int n);

#endif
