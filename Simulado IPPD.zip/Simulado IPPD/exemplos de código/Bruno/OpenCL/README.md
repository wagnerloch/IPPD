Alguns exercícios e exemplos disponíveis no AVA.

gcc main.c -o vectorAddition -l OpenCL
