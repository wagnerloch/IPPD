Exercise 4 - Chaining vector add kernels (C++/Python)
=====================================================
