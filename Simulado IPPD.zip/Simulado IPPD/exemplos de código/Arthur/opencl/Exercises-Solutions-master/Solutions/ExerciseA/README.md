Exercise A - The vectorized Pi program
======================================
