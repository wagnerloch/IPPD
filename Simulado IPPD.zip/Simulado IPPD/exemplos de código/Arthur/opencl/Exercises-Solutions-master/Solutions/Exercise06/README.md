Exercise 6 - Matrix Multiplication
==================================
