1. gcc -o executable -fopenmp file.c 
2. export OMP_NUM_THREADS=2 (optional)
3. ./executable