# IPPD

* Instalação:
- sudo apt install libopenmpi-dev openmpi-bin openmpi-doc

* Excercícios 1:
1. Ping-Pong (Imprime onde está a bola)
2. Anel (Imprime onde está o anel)
3. Trabalho em Equipe (Escolher alguma implementação paralela)
4. Apresentar quanto cada processo aguardou, trabalhou, etc