1. su nrc (se estiver no lab, em máquina pessoal utilizar root)
2. sudo apt install libopenmpi-dev openmpi-bin openmpi-doc
3. Usar mpicc para compilar ($ mpicc file.c -o executable)
4. Usar mpirun para executar ($ mpirun -n num_of_processes executable)