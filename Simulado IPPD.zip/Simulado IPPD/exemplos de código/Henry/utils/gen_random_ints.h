
int *gen_random_ints(unsigned int, unsigned int);

int assert_asc_order(int[], int);
