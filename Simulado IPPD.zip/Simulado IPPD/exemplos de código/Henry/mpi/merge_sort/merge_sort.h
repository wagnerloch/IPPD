void merge_sort (
        int[], 
        unsigned int start,
        unsigned int end);

void merge (
        int[], 
        unsigned int start, 
        unsigned int middle, 
        unsigned int  end);

void print_int_arr(int[], unsigned int, unsigned int);
        