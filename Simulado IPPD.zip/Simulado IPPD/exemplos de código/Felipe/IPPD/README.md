# IPPD
---

Repositório para disciplina de Introdução ao Processamento Paralelo e Distribuído.

### Para compilar projetos OpenMP
    gcc -o output -fopenmp input.c
